# ecommerce-api
JSONs container para simular una Api REST para el ecommerce e-Mercado.
